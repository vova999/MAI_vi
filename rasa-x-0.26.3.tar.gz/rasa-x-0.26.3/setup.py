from setuptools import setup, find_packages

# Read version from version.py
__version__ = None
with open("rasax/community/version.py") as f:
    exec(f.read())

tests_requires = [
    "python-coveralls~=2.9",
    "pytest-cov~=2.7",
    "pytest-pycodestyle~=1.4",
    "pytest-services~=1.3",
    "pytest~=5.3",
    "pytest-sanic~=1.6.0",
    "aioresponses~=0.6.0",
]

install_requires = [
    "pyjwt",  # no version pinning needed due to sanic-jwt
    "python-dateutil~=2.8",
    "isodate~=0.6.0",
    "jsonschema~=3.2",
    "SQLAlchemy~=1.3.0",
    "alembic~=1.0.10",
    "pika~=1.1.0",
    "requests~=2.22",
    "sanic~=19.12.2",
    "sanic-cors~=0.10.0.post3",
    "sanic-jwt~=1.3",
    "aiohttp~=3.6",
    "apscheduler~=3.6",
    "questionary~=1.5",
    "attrs>=18",
    "cryptography~=2.7",
    "pyyaml~=5.1",
    "GitPython~=3.0",
    # currently sanic only specifies ujson = ">=1.35", but 2.0 breaks our tests
    "ujson<2.0",
    # Please check the README to see all locations which have to be updated!
    "rasa>=1.8.1,<1.9",
]

extras_requires = {
    "test": tests_requires,
    "sql": ["psycopg2~=2.8"],
    "kafka": ["kafka-python~=1.4.0"],
}

# we need to where as there is no __init__.py in `rasax` because of the
# multi package build. the resulting package name will miss the
# `rasax.community` prefix, which we need to add manually
sub_packages = find_packages(where="rasax/community", exclude=["tests", "tools"])

base_package = "rasax.community"

packages = [base_package + "." + p for p in sub_packages]

setup(
    name="rasa-x",
    packages=packages + [base_package],
    package_data={"": ["alembic.ini"]},
    zip_safe=False,
    classifiers=[
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
    ],
    python_requires=">=3.6",
    install_requires=install_requires,
    tests_require=tests_requires,
    extras_require=extras_requires,
    include_package_data=True,
    description="Rasa X",
    author="Rasa Technologies GmbH",
    author_email="hi@rasa.com",
    url="https://rasa.com",
    version=__version__,
)
