import datetime
import hashlib
import logging
import uuid
import aiohttp
import asyncio  # pytype: disable=pyi-error
import requests
import ctypes
import urllib.parse
from functools import wraps
from typing import Any, Dict, Optional, Text, Tuple, TYPE_CHECKING

from sqlalchemy.orm import Session

from rasa.cli import utils as rasa_cli_utils
from rasa.constants import GLOBAL_USER_CONFIG_PATH
from rasa.utils import common as rasa_utils

from rasax.community.database import utils as db_utils
from rasax.community import config, utils, constants
from rasax.community.services.config_service import (
    ConfigService,
    ConfigKey,
    MissingConfigValue,
    InvalidConfigValue,
)
from rasa.utils.io import DEFAULT_ENCODING
from rasax.community.constants import (
    CONFIG_TELEMETRY_ENABLED,
    CONFIG_TELEMETRY_ID,
    CONFIG_FILE_TELEMETRY_KEY,
    CONFIG_TELEMETRY_DATE,
    CONFIG_TELEMETRY_WELCOME_SHOWN,
    RASA_PRODUCTION_ENVIRONMENT,
)

from rasax.community.version import __version__

if TYPE_CHECKING:
    from multiprocessing import Array, Value  # type: ignore

logger = logging.getLogger(__name__)

SEGMENT_ENDPOINT = "https://api.segment.io/v1/track"
TELEMETRY_HTTP_TIMEOUT = 2  # Seconds
ENVIRONMENT_LIVE_TIMEOUT = 2  # Seconds
TELEMETRY_ID = "metrics_id"
TELEMETRY_ID_LENGTH = 64

# If updating or creating a new event, remember to update
# docs/telemetry/events.json as well!
LOCAL_START_EVENT = "Local X Start"
SERVER_START_EVENT = "Server X Start"
TELEMETRY_CONSENT_EVENT = "Metrics Consent"
MODEL_TRAINED_EVENT = "Model Trained"
MODEL_UPLOADED_EVENT = "Model Uploaded"
MODEL_PROMOTED_EVENT = "Model Promoted"
MESSAGE_RECEIVED_EVENT = "Message Received"
MESSAGE_ANNOTATED_EVENT = "Message Annotated"
MESSAGE_FLAGGED_EVENT = "Message Flagged"
STORY_CREATED_EVENT = "Story Created"
STATUS_EVENT = "Status"
REPOSITORY_CREATED_EVENT = "Repository Created"
GIT_CHANGES_PUSHED_EVENT = "Git Changes Pushed"
FEATURE_FLAG_UPDATED_EVENT = "Feature Flag Updated"
CONVERSATION_TAGGED = "Conversation Tagged"
CONVERSATIONS_IMPORTED_EVENT = "Conversations Imported"

MESSAGE_ANNOTATED_CONVERSATIONS = "conversations"
MESSAGE_ANNOTATED_NEW_DATA = "annotate_new_data"
MESSAGE_ANNOTATED_INTERACTIVE_LEARNING = "interactive_learning"

STORY_CREATED_INTERACTIVE = "interactive"
STORY_CREATED_STORIES = "stories"

# Loaded telemetry config local to this process
_telemetry_enabled = None
_telemetry_id = None


def is_telemetry_enabled() -> bool:
    """Indicates whether telemetry is enabled or not.

    Returns:
        `True` if telemetry is enabled, `False` otherwise.
    """
    if _telemetry_enabled is None:
        return False

    return _telemetry_enabled.value


def telemetry_id() -> Optional[Text]:
    """Returns the unique telemetry ID for this Rasa X server.

    Returns:
        String containing the unique ID (which should be a UUID).
    """
    if _telemetry_id is None:
        return None

    return _telemetry_id.value.decode(DEFAULT_ENCODING) or None


def get_telemetry_config() -> Tuple["Value", "Array"]:
    """Get the telemetry configuration variables for this process.
    If the telemetry configuration variables have not been initialized yet,
    initialize them with default values.

    Returns:
        Tuple containing two multiprocessing variables: a boolean representing
        whether telemetry is enabled or not, and a char array containing the
        telemetry ID.
    """
    global _telemetry_enabled, _telemetry_id

    if _telemetry_enabled is None:
        _telemetry_enabled = utils.mp_context().Value(ctypes.c_bool, False)

    if _telemetry_id is None:
        _telemetry_id = utils.mp_context().Array(ctypes.c_char, TELEMETRY_ID_LENGTH)

    return _telemetry_enabled, _telemetry_id


def set_telemetry_config(enabled: "Value", telemetry_id: "Array") -> None:
    """Set the telemetry configuration for this process. If the values have
    been taken from another process, then the two will share the same values
    (even if they are modified).

    If the process already has its telemetry configuration variables set, then
    don't overwrite them, as this means we have inherited them from a fork, and
    therefore already share them with our parent. If they are set to `None` on
    the other hand, then it probably means this process has been started using
    the "spawn" context, and therefore shares no state with its creator.

    Args:
        enabled: Multiprocessing boolean value indicating whether telemetry is
            enabled or not.
        telemetry_id: Multiprocessing char array value containing the telemetry ID.
    """
    global _telemetry_enabled, _telemetry_id

    if _telemetry_enabled is None:
        _telemetry_enabled = enabled
    else:
        logger.debug(
            "Not setting `_telemetry_enabled` as it's already set on this process."
        )

    if _telemetry_id is None:
        _telemetry_id = telemetry_id
    else:
        logger.debug("Not setting `_telemetry_id` as it's already set on this process.")


def ensure_telemetry_enabled(f):
    """Function decorator for telemetry functions that only runs the decorated
    function if telemetry is enabled, and if the telemetry user ID is set. All
    exceptions generated by the decorated functions are catched and logged."""

    @wraps(f)
    def decorated(*args, **kwargs):
        try:
            if is_telemetry_enabled() and telemetry_id():
                f(*args, **kwargs)
        except Exception as e:
            logger.debug(f"Skipping telemetry collection: {e}")

    return decorated


def segment_request_header(write_key: Text) -> Dict[Text, Any]:
    """Use a segment write key to create authentication headers for the segment API."""

    return {
        "Authorization": "Basic {}".format(utils.encode_base64(write_key + ":")),
        "Content-Type": "application/json",
    }


def segment_request_payload(
    distinct_id: Text,
    event_name: Text,
    properties: Optional[Dict[Text, Any]] = None,
    context: Optional[Dict[Text, Any]] = None,
) -> Dict[Text, Any]:
    """Compose a valid payload for the segment API."""

    return {
        "userId": distinct_id,
        "event": event_name,
        "properties": properties or {},
        "context": context or {},
    }


async def _track_async(
    distinct_id: Text,
    event_name: Text,
    properties: Optional[Dict[Text, Any]] = None,
    context: Optional[Dict[Text, Any]] = None,
) -> None:
    """Sends the contents of an event to the /track Segment endpoint.
    Documentation: https://segment.com/docs/sources/server/http/

    Do not call this function from outside telemetry.py! This function does not
    check if telemetry is enabled or not.

    Args:
        distinct_id: Unique telemetry ID.
        event_name: Name of the event.
        properties: Values to send along the event.
        context: Context information about the event.
    """

    async with aiohttp.ClientSession() as session:
        headers = segment_request_header(config.telemetry_write_key)

        payload = segment_request_payload(distinct_id, event_name, properties, context)

        if utils.in_continuous_integration():
            logger.info("Skip sending telemetry event: running in a CI context.")
            return

        try:
            async with session.post(
                SEGMENT_ENDPOINT,
                raise_for_status=True,
                headers=headers,
                json=payload,
                timeout=TELEMETRY_HTTP_TIMEOUT,
            ) as resp:
                data = (await resp.json()) or {}
                if not data.get("success"):
                    raise Exception(
                        f"Got an unsuccessful response from Segment: {data}"
                    )
        except Exception as e:
            logger.debug("An error ocurred when trying to send telemetry data.")
            logger.debug(f"Exception message: {e}")


def _track_internal(
    distinct_id: Text,
    event_name: Text,
    properties: Optional[Dict[Text, Any]] = None,
    context: Optional[Dict[Text, Any]] = None,
) -> None:
    """Tracks an event.

    If there's no event loop running on the current thread, `_track_internal`
    will block until the tracking HTTP request is sent. Otherwise, the task
    will be scheduled to run and the function will immediately return.

    Do not call this function from outside telemetry.py! This function does not
    check if telemetry is enabled or not.

    Args:
        distinct_id: Unique telemetry ID.
        event_name: Name of the event.
        properties: Values to send along the event.
        context: Context information about the event.
    """

    coro = _track_async(distinct_id, event_name, properties, context)
    # get_event_loop() will create a new (unstarted) loop if the current
    # thread has no active one.
    loop = asyncio.get_event_loop()

    if loop.is_running():
        # We are being called after Sanic's loop has started.
        loop.create_task(coro)
    else:
        # We are being called before Sanic's loop has started, therefore run
        # the coroutune using run_until_complete() (this will start and stop
        # the event loop).
        loop.run_until_complete(coro)


@ensure_telemetry_enabled
def track(
    event_name: Text,
    properties: Optional[Dict[Text, Any]] = None,
    context: Optional[Dict[Text, Any]] = None,
) -> None:
    """Tracks a telemetry event.

    It is OK to use this function from outside telemetry.py, but note that it
    is recommended to create a new track_xyz() function for complex telemetry
    events, or events that are generated from many parts of the Rasa X code.

    Args:
        event_name: Name of the event.
        properties: Dictionary containing the event's properties.
        context: Dictionary containing some context for this event.
    """

    if properties:
        properties[TELEMETRY_ID] = telemetry_id()

    _track_internal(telemetry_id(), event_name, properties, context)


def track_telemetry_consent(
    user_id: Text, allow_telemetry: bool, auto_accept: bool = False
) -> None:
    """Tracks the telemetry consent event."""

    # Use _track_internal() instead of track() to bypass is_telemetry_enabled() check
    try:
        _track_internal(
            user_id,
            TELEMETRY_CONSENT_EVENT,
            {"allow_metrics_collection": allow_telemetry, "auto_accept": auto_accept},
        )
    except Exception as e:
        logger.debug(f"Skipping telemetry collection: {e}")


async def track_status_periodically() -> None:
    """Coroutine that tracks the current state of the project every fixed amount of
    seconds."""

    while True:
        logger.debug("Sending periodic telemetry event.")
        track_project_status()
        await asyncio.sleep(config.telemetry_status_event_interval)


@ensure_telemetry_enabled
def track_project_status(session: Optional[Session] = None) -> None:
    """Tracks an event which describes the current state of the project.

    Args:
        session: Optional database session to use. If not provided, create a
            new one with `session_scope`.
    """

    if not session:
        with db_utils.session_scope() as db_session:
            status_event = _get_project_status_event(db_session)
    else:
        status_event = _get_project_status_event(session)

    track(STATUS_EVENT, status_event)


def _is_rasa_environment_live(url: Text) -> bool:
    """Determine whether rasa environment at `url` is live.

    Args:
        url: URL of the environment.

    Returns:
        `True` or `False` indicating if the environment is live or not.
    """

    try:
        response = requests.get(f"{url}/version", timeout=ENVIRONMENT_LIVE_TIMEOUT)
        return response.status_code == 200
    except requests.RequestException:
        return False


def _get_project_status_event(
    session: Session, project_id: Text = config.project_name
) -> Dict[Text, Any]:
    """Collect data used in `status` event.

    Args:
        session: Database session.
        project_id: The project ID.

    Returns:
        A dictionary containing statistics describing the current project's status.
    """

    from rasax.community.services.event_service import EventService
    from rasax.community.services.domain_service import DomainService
    from rasax.community.services.model_service import ModelService
    from rasax.community.services.data_service import DataService
    from rasax.community.services.story_service import StoryService
    from rasax.community.services.settings_service import SettingsService

    event_service = EventService(session)
    domain_service = DomainService(session)
    model_service = ModelService(config.rasa_model_dir, session)
    data_service = DataService(session)
    story_service = StoryService(session)
    settings_service = SettingsService(session)

    domain = domain_service.get_domain(project_id) or {}
    nlu_data = data_service.get_nlu_training_data_object(project_id=project_id)
    stories = story_service.fetch_stories()

    num_conversations = event_service.get_conversation_metadata_for_all_clients().count
    num_models = model_service.get_model_count()
    lookup_tables = data_service.get_lookup_tables(project_id, include_filenames=True)
    num_lookup_table_files = len({table["filename"] for table in lookup_tables})
    num_lookup_table_entries = sum(
        table.get("number_of_elements", 0) for table in lookup_tables
    )
    synonyms = data_service.get_entity_synonyms(project_id)
    num_synonyms = sum(len(entry["synonyms"]) for entry in synonyms)
    num_regexes = data_service.get_regex_features(project_id).count
    environments = settings_service.get_environments_config(project_id)["environments"][
        "rasa"
    ]
    environment_names = [
        (
            name
            if name in [RASA_PRODUCTION_ENVIRONMENT, "worker", "development"]
            else hashlib.sha256(name.encode("utf-8")).hexdigest()
        )
        for name in environments
    ]
    num_live_environments = len(
        [
            environment
            for environment in environments.values()
            if _is_rasa_environment_live(environment["url"])
        ]
    )

    tags = event_service.get_all_conversation_tags()
    conversations_with_tags = set()
    for tag in tags:
        conversations_with_tags.update(tag["conversations"])

    return {
        # Use the SHA256 of the project ID in case its value contains
        # information about the user's use of Rasa X. On the analytics side,
        # having the original value or the hash makes no difference. This
        # reasoning is also applied on other values sent in this module.
        "project": hashlib.sha256(project_id.encode("utf-8")).hexdigest(),
        "local_mode": config.LOCAL_MODE,
        "rasa_x": __version__,
        "num_intent_examples": len(nlu_data.intent_examples),
        "num_entity_examples": len(nlu_data.entity_examples),
        "num_actions": len(domain.get("actions", [])),
        "num_templates": len(domain.get("responses", [])),
        "num_slots": len(domain.get("slots", [])),
        "num_forms": len(domain.get("forms", [])),
        "num_intents": len(domain.get("intents", [])),
        "num_entities": len(domain.get("entities", [])),
        "num_stories": len(stories),
        "num_conversations": num_conversations,
        "num_models": num_models,
        "num_lookup_table_files": num_lookup_table_files,
        "num_lookup_table_entries": num_lookup_table_entries,
        "num_synonyms": num_synonyms,
        "num_regexes": num_regexes,
        "num_environments": len(environments),
        "environment_names": environment_names,
        "num_live_environments": num_live_environments,
        "uptime_seconds": utils.get_uptime(),
        "num_tags": len(tags),
        "num_conversations_with_tags": len(conversations_with_tags),
    }


@ensure_telemetry_enabled
def track_story_created(referrer: Optional[Text]) -> None:
    """Tracks an event when a new story is created."""

    if not referrer:
        return

    origin = None
    path = urllib.parse.urlparse(referrer).path

    if path.startswith("/interactive"):
        origin = STORY_CREATED_INTERACTIVE
    elif path.startswith("/stories"):
        origin = STORY_CREATED_STORIES

    if origin:
        track(STORY_CREATED_EVENT, {"story_created_from": origin})


@ensure_telemetry_enabled
def track_message_annotated(origin: Text) -> None:
    """Tracks an event when a message is annotated."""

    track(MESSAGE_ANNOTATED_EVENT, {"message_annotated_from": origin})


@ensure_telemetry_enabled
def track_message_annotated_from_referrer(referrer: Optional[Text] = None) -> None:
    """Tracks an event when a message is annotated, using a 'Referer' HTTP
    header value to determine the origin of the event."""

    if not referrer:
        return

    path = urllib.parse.urlparse(referrer).path

    if path.startswith("/conversations"):
        origin = MESSAGE_ANNOTATED_CONVERSATIONS
    elif path.startswith("/data"):
        origin = MESSAGE_ANNOTATED_NEW_DATA

    track_message_annotated(origin)


@ensure_telemetry_enabled
def track_message_received(username: Text, channel: Optional[Text]) -> None:
    """Tracks an event when a message is received."""

    track(
        MESSAGE_RECEIVED_EVENT,
        {
            "username": hashlib.sha256(username.encode("utf-8")).hexdigest(),
            "channel": channel or constants.DEFAULT_CHANNEL_NAME,
        },
    )


def _read_telemetry_consent(no_prompt: bool) -> bool:
    """Check if the user wants to enable telemetry or not.

    Args:
        no_prompt: If `True`, do not prompt the user for input (but inform
            about any decision taken).

    Returns:
        Boolean indicating if the user wants to enable telemetry.
    """
    import questionary

    allow_telemetry = (
        questionary.confirm(
            "Rasa will track a minimal amount of anonymized usage information "
            "(like how often the 'train' button is used) to help us improve Rasa X. "
            "None of your training data or conversations will ever be sent to Rasa. "
            "Are you OK with Rasa collecting anonymized usage data?"
        )
        .skip_if(no_prompt, default=True)
        .ask()
    )

    if not no_prompt:
        rasa_cli_utils.print_success(
            f"Your decision has been stored into '{GLOBAL_USER_CONFIG_PATH}'."
        )
    else:
        rasa_cli_utils.print_info(
            "By adding the '--no_prompt' parameter you agreed to allow Rasa to track "
            "and send anonymized usage information."
        )

    return allow_telemetry


def initialize_configuration_from_file(no_prompt: bool) -> None:
    """Read telemetry configuration from the user's Rasa config file in $HOME.

    Args:
        no_prompt: If `True`, do not prompt the user for input.
    """
    if not config.LOCAL_MODE:
        logger.error(
            "Attempted to read telemetry configuration file in $HOME while in server "
            "mode. Telemetry will not be enabled."
        )
        return

    telemetry_enabled_mp, telemetry_id_mp = get_telemetry_config()

    try:
        stored_config = rasa_utils.read_global_config_value(
            CONFIG_FILE_TELEMETRY_KEY, unavailable_ok=False
        )

        telemetry_enabled_mp.value = stored_config[CONFIG_TELEMETRY_ENABLED]
        telemetry_id_mp.value = stored_config[CONFIG_TELEMETRY_ID].encode(
            DEFAULT_ENCODING
        )

        return
    except ValueError as e:
        logger.debug(f"Could not read telemetry settings from configuration file: {e}")

    allow_telemetry = _read_telemetry_consent(no_prompt)

    new_config = {
        CONFIG_TELEMETRY_ENABLED: allow_telemetry,
        CONFIG_TELEMETRY_ID: uuid.uuid4().hex,
        CONFIG_TELEMETRY_DATE: datetime.datetime.now(),
        CONFIG_TELEMETRY_WELCOME_SHOWN: False,
    }

    rasa_utils.write_global_config_value(CONFIG_FILE_TELEMETRY_KEY, new_config)
    track_telemetry_consent(new_config[CONFIG_TELEMETRY_ID], allow_telemetry, no_prompt)

    telemetry_enabled_mp.value = allow_telemetry
    telemetry_id_mp.value = new_config[CONFIG_TELEMETRY_ID].encode(DEFAULT_ENCODING)


def initialize_configuration_from_db(session: Session) -> None:
    """Read telemetry configuration from the database.

    Args:
        session: Database session to use.
    """

    if config.LOCAL_MODE:
        logger.error(
            "Attempted to read telemetry configuration from the database while in "
            "local mode. Telemetry will not be enabled."
        )
        return

    config_service = ConfigService(session)
    # Initialize the general configuration, just in case. If this has already
    # been done before then this call is a no-op.
    config_service.initialize_configuration()

    telemetry_enabled = False
    telemetry_id = None

    try:
        telemetry_enabled = config_service.get_value(
            ConfigKey.TELEMETRY_ENABLED, expected_type=bool
        )
        telemetry_id = config_service.get_value(
            ConfigKey.TELEMETRY_UUID, expected_type=str
        )
    except (MissingConfigValue, InvalidConfigValue) as e:
        logger.warning(f"Could not read telemetry configuration: {e}.")

    telemetry_enabled_mp, telemetry_id_mp = get_telemetry_config()

    telemetry_enabled_mp.value = telemetry_enabled
    telemetry_id_mp.value = (telemetry_id or "").encode(DEFAULT_ENCODING)

    set_telemetry_config(telemetry_enabled_mp, telemetry_id_mp)


@ensure_telemetry_enabled
def track_repository_creation(target_branch: Text, created_via_ui: bool) -> None:
    """Tracks when a new Git repository was connected to Rasa X server.

    Args:
        target_branch: The target branch of this repository.
        created_via_ui: `True` if the repository was created using the Rasa X UI.
    """

    track(
        REPOSITORY_CREATED_EVENT,
        {"branch": target_branch, "created_with_ui": created_via_ui},
    )


@ensure_telemetry_enabled
def track_git_changes_pushed(branch: Text) -> None:
    """Track when changes were pushed to the remote Git repository.

    Args:
        branch: Name of the branch the changes were pushed to.
    """

    track(GIT_CHANGES_PUSHED_EVENT, {"branch": branch})


@ensure_telemetry_enabled
def track_feature_flag(feature_name: Text, enabled: bool) -> None:
    """Track when a feature flag was enabled / disabled.

    Args:
        feature_name: Name of the feature.
        enabled: `True` if the feature was enabled, otherwise `False`.
    """

    track(FEATURE_FLAG_UPDATED_EVENT, {"name": feature_name, "enabled": enabled})


@ensure_telemetry_enabled
def track_conversation_tagged(count: int) -> None:
    """Track an event when a conversation is tagged with one or more tags.

    Args:
        count: Number of tags assigned to the conversation.
    """

    track(CONVERSATION_TAGGED, {"count": count})


@ensure_telemetry_enabled
def track_conversations_imported(process_id: Text) -> None:
    """Track when conversations were imported through a `rasa export` call.

    Args:
        process_id: Import process ID.

    """
    track(CONVERSATIONS_IMPORTED_EVENT, {"process_id": process_id})
